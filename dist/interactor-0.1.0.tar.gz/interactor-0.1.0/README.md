# Running FextractOmics

python FextractOmics.py
